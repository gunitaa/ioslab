import UIKit


// till 1 to 5
for index in 1...5{
    print("Index =\(index)")
}
//from 1 until smaller than  5
for index in 1..<5
{
    print("Index =\(index)")
}
//when not using index

for _ in 1...3
{
    print("Hello")
}


var names = ["John","Jane","Jin","Richard"]
//when iterating an array
for name in names{
    print ("Hello \(name)")
}
//iterate a string
//creates a tuple
//when you want to see the indexing and the letter both
for (index,letter) in "Gunita".enumerated(){
    print("\(index)    \(letter)")
}

//using a dixtionary
var dict=["unicycle":1,"bicycle":2,"tricycle":3,"car":4]

for (vehiclename,wheelcount) in dict{
    print(vehiclename + "\(wheelcount)")
    
}


//while loop

var numLives=4
while numLives > 0 {
    
    print("You have \(numLives) lives left")
    numLives-=1
}


var steps=0

repeat{
    print("Number of steps: \(steps)")
    steps += 1
}
while steps<10

        for counter in -3 ... 3{
    print(counter)
    if(counter == 0 ){
        break
    }
}
print("executed once the loop ends")
