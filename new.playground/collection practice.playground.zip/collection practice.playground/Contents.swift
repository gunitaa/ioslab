import UIKit

var name = ["Sajal","Aman","John","Rohit"]

//checks if an array contains the element
name.contains("Sajal")
//counts the number of elements
print(name.count)
//prints array at given index
print(name[2])
//changes the element at given index
name[2]="Rahul"
//adds an elemts in an array
name.append("Joe")

//another way to append elmnts in an array
name+=["Anthony","Jane"]

print(name)
//appends elmnt at given index
name.insert("Bob",at:3)
print(name)

//removing elements from an array at some position
let remove1=name.remove(at: 3)
print(name)
//removing elemts from the last
name.removeLast()
print(name)
//contains the repeating element count times
var myArray = [String](repeating: "33", count: 10)
print(myArray)
//checks if an array is empty
myArray.isEmpty

//adds two arrays of same type
var newArray=name+myArray
print(newArray)

//2-D array
var array1=[1,2,3]
var array2=[4,5,6]
var newArray2=[array1,array2]
print(newArray2[0])
let firstElement=newArray2[0][0]
print(newArray2[0][0])

//removes all elements from an given array
name.removeAll()


//Dictionaries
//created a dict.
var scores = ["Oli":399,"Cheryl":800,"Richard":500]
//changed the scores for given key
scores["Oli"]=444
print(scores)
//changed value for given key
scores.updateValue(445, forKey: "Cheryl")
print(scores)
//removed a value
scores.removeValue(forKey: "Oli")
//you could also write
//scores["Oli"]=nil    --this also removes the value

print(scores)


//storing dict. as an array
let name1=Array(scores.keys)
let points = Array(scores.values)

print(name1)
print(points)

var score=["Richard":399,"Luke":800,"Cheryl":500]
