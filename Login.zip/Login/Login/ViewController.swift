import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var forgotPasswordButton: UIButton!
    
    @IBOutlet var forgotUsernameButton: UIButton!
    @IBOutlet var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    @IBAction func unwindToRed(unwindSegue: UIStoryboardSegue){
        
    }
    @IBAction func forgotPasswordButton(_ sender: UIButton) {
        performSegue(withIdentifier: "ForgottenPassword", sender: sender)
    }
    @IBAction func forgotUsernameButton(_ sender: UIButton) {
        performSegue(withIdentifier: "ForgottenUsername", sender: sender)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        if sender == forgotPasswordButton {
            segue.destination.navigationItem.title = "Forgot Password"        }
        else if sender == forgotUsernameButton {
            segue.destination.navigationItem.title = "Forgot Username"
        }
        else {
            segue.destination.navigationItem.title = textField.text}
        
    }
    

}

