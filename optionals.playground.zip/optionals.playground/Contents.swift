import UIKit

struct Book{
    var name:String
    var announcementDate:Int? //optional int
}
let firstBook = Book(name:"FirstBook",announcementDate: 2024)
let secondBook = Book(name:"SecondBook",announcementDate: 2023)
var books: [Book]? = [firstBook,secondBook]

books = nil
let thirdBook:Book = Book(name:"ThirdBook",announcementDate: nil)
let display = thirdBook.announcementDate ?? 2022
print(display)

//ways to unwrap the optional
if let books = thirdBook.announcementDate{
    print("\(books)")
}

if thirdBook.announcementDate != nil{
    print(thirdBook.announcementDate!) // never forget to use ! otherwise prints nil valuyes
    
}



//functions and optionals
let string = "123"
let intvalue=Int(string)
print(intvalue)


//failable initializers
struct Toddler{
    var name:String
    var monthsOld:Int
    
    init?(name:String,monthsOld:Int){
        if(monthsOld<12||monthsOld>36){
            return nil
        }
        else{
            self.name=name
            self.monthsOld=monthsOld
        }
    }
}


struct Person{
    var age: Int
    var residence: Residence?
}
struct Residence{
    var address: Address?
}
struct Address{
    var buildingNumber:String?
    var streetName: String?
    var apartmentNumber: String?
}

let firstPerson = Person(age: 20, residence: Residence(address: Address(buildingNumber: "11-A",streetName: "Abc",apartmentNumber: "420")))

if let firstPerson = firstPerson.residence?.address?.apartmentNumber{
    print(firstPerson)
}
if let firstPerson = firstPerson.residence?.address?.buildingNumber{
    print(firstPerson)
}
if let firstPerson = firstPerson.residence?.address?.streetName{
    print(firstPerson)
}
