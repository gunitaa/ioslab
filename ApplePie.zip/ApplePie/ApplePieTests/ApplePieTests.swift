//
//  ApplePieTests.swift
//  ApplePieTests
//
//  Created by Student on 22/07/25.
//

import Testing
@testable import ApplePie

struct ApplePieTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
